<?php return array (
  'admin.booking.index' => 'App\\Http\\Livewire\\Admin\\Booking\\Index',
  'admin.facility.index' => 'App\\Http\\Livewire\\Admin\\Facility\\Index',
  'admin.guest.index' => 'App\\Http\\Livewire\\Admin\\Guest\\Index',
  'admin.room.index' => 'App\\Http\\Livewire\\Admin\\Room\\Index',
  'admin.roomtype.index' => 'App\\Http\\Livewire\\Admin\\Roomtype\\Index',
  'admin.user.index' => 'App\\Http\\Livewire\\Admin\\User\\Index',
  'admin.website.menu.index' => 'App\\Http\\Livewire\\Admin\\Website\\Menu\\Index',
  'admin.website.submenu.index' => 'App\\Http\\Livewire\\Admin\\Website\\Submenu\\Index',
);