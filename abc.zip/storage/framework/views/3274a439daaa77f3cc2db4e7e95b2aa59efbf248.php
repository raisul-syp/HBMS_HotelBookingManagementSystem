<?php $__env->startSection('title', 'Menu List'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h2 class="page-header-title"><?php echo e(__('Menu List')); ?></h2>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0)"><?php echo e(__('Website')); ?></a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0)"><?php echo e(__('Menu')); ?></a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0)"><?php echo e(__('Menu List')); ?></a></li>
                </ol>
            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <a href="<?php echo e(url('admin/website/menu/create')); ?>" class="btn btn-success text-white mr-1"><?php echo e(__('Add Menu')); ?></a>
            <a href="<?php echo e(url('admin/website/submenu/create')); ?>" class="btn btn-success text-white mr-1"><?php echo e(__('Add Submenu')); ?></a>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <?php if(session('message')): ?>
                <?php echo $__env->make('alertMessage.admin.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.website.menu.index', [])->html();
} elseif ($_instance->childHasBeenRendered('FjJ9APf')) {
    $componentId = $_instance->getRenderedChildComponentId('FjJ9APf');
    $componentTag = $_instance->getRenderedChildComponentTagName('FjJ9APf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FjJ9APf');
} else {
    $response = \Livewire\Livewire::mount('admin.website.menu.index', []);
    $html = $response->html();
    $_instance->logRenderedChild('FjJ9APf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Works\Office\SYP\HBMS_HotelBookingManagementSystem\resources\views/admin/website/menu/index.blade.php ENDPATH**/ ?>