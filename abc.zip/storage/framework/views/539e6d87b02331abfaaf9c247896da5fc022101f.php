<div class="quixnav-scroll">
    <ul class="metismenu" id="menu">
        <li>
            <a href="<?php echo e(url('admin/dashboard')); ?>">
                <i class="icon icon-single-04"></i>
                <span class="nav-text"><?php echo e(__('Dashboard')); ?></span>
            </a>
        </li>
        <li>
            <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                <i class="icon icon-single-04"></i>
                <span class="nav-text"><?php echo e(__('Room Type')); ?></span>
            </a>
            <ul aria-expanded="false">
                <li><a href="<?php echo e(url('admin/roomtype/create')); ?>"><?php echo e(__('Add Room Type')); ?></a></li>
                <li><a href="<?php echo e(url('admin/roomtype')); ?>"><?php echo e(__('All Room Type')); ?></a></li>
            </ul>
        </li>
        <li>
            <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                <i class="icon icon-single-04"></i>
                <span class="nav-text"><?php echo e(__('Facilities')); ?></span>
            </a>
            <ul aria-expanded="false">
                <li><a href="<?php echo e(url('admin/facility/create')); ?>"><?php echo e(__('Add Facility')); ?></a></li>
                <li><a href="<?php echo e(url('admin/facility')); ?>"><?php echo e(__('All Facility')); ?></a></li>
            </ul>
        </li>
        <li>
            <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                <i class="icon icon-single-04"></i>
                <span class="nav-text"><?php echo e(__('Rooms')); ?></span>
            </a>
            <ul aria-expanded="false">
                <li><a href="<?php echo e(url('admin/room/create')); ?>"><?php echo e(__('Add Room')); ?></a></li>
                <li><a href="<?php echo e(url('admin/room')); ?>"><?php echo e(__('All Room')); ?></a></li>
            </ul>
        </li>
        <li>
            <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                <i class="icon icon-single-04"></i>
                <span class="nav-text"><?php echo e(__('Bookings')); ?></span>
            </a>
            <ul aria-expanded="false">
                <li><a href="<?php echo e(url('admin/booking/create')); ?>"><?php echo e(__('Add Booking')); ?></a></li>
                <li><a href="<?php echo e(url('admin/booking')); ?>"><?php echo e(__('All Booking')); ?></a></li>
            </ul>
        </li>
        <li>
            <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                <i class="icon icon-single-04"></i>
                <span class="nav-text"><?php echo e(__('Guests')); ?></span>
            </a>
            <ul aria-expanded="false">
                <li><a href="<?php echo e(url('admin/guest/create')); ?>"><?php echo e(__('Add Guest')); ?></a></li>
                <li><a href="<?php echo e(url('admin/guest')); ?>"><?php echo e(__('All Guest')); ?></a></li>
            </ul>
        </li>
        <li>
            <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                <i class="icon icon-single-04"></i>
                <span class="nav-text"><?php echo e(__('Users')); ?></span>
            </a>
            <ul aria-expanded="false">
                <li><a href="<?php echo e(url('admin/user/create')); ?>"><?php echo e(__('Add User')); ?></a></li>
                <li><a href="<?php echo e(url('admin/user')); ?>"><?php echo e(__('All User')); ?></a></li>
            </ul>
        </li>
        <li>
            <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                <i class="icon icon-single-04"></i>
                <span class="nav-text"><?php echo e(__('Website')); ?></span>
            </a>
            <ul aria-expanded="false">
                <li>
                    <a class="has-arrow" href="javascript:void()" aria-expanded="false"><?php echo e(__('Menu')); ?></a>
                    <ul aria-expanded="false">
                        <li><a href="<?php echo e(url('admin/website/menu/create')); ?>"><?php echo e(__('Add Menu')); ?></a></li>
                        <li><a href="<?php echo e(url('admin/website/menu')); ?>"><?php echo e(__('All Menu')); ?></a></li>
                    </ul>
                </li>
                <li>
                    <a class="has-arrow" href="javascript:void()" aria-expanded="false"><?php echo e(__('Submenu')); ?></a>
                    <ul aria-expanded="false">
                        <li><a href="<?php echo e(url('admin/website/submenu/create')); ?>"><?php echo e(__('Add Submenu')); ?></a></li>
                        <li><a href="<?php echo e(url('admin/website/submenu')); ?>"><?php echo e(__('All Submenu')); ?></a></li>
                    </ul>
                </li>
            </ul>
        </li>
    </ul>
</div>
<?php /**PATH E:\Works\Office\SYP\HBMS_HotelBookingManagementSystem\resources\views/layouts/inc/admin/sidebar.blade.php ENDPATH**/ ?>