
<?php $__env->startSection('title', 'Facility List'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h2 class="page-header-title"><?php echo e(__('Facility List')); ?></h2>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0)"><?php echo e(__('Facilities')); ?></a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0)"><?php echo e(__('Facility List')); ?></a></li>
                </ol>
            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <a href="<?php echo e(url('admin/facility/create')); ?>" class="btn btn-success text-white"><?php echo e(__('Add Facility')); ?></a>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <?php if(session('message')): ?>
                <?php echo $__env->make('alertMessage.admin.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.facility.index', [])->html();
} elseif ($_instance->childHasBeenRendered('AsrVKHt')) {
    $componentId = $_instance->getRenderedChildComponentId('AsrVKHt');
    $componentTag = $_instance->getRenderedChildComponentTagName('AsrVKHt');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AsrVKHt');
} else {
    $response = \Livewire\Livewire::mount('admin.facility.index', []);
    $html = $response->html();
    $_instance->logRenderedChild('AsrVKHt', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Works\Office\SYP\HBMS_HotelBookingManagementSystem\resources\views/admin/facility/index.blade.php ENDPATH**/ ?>