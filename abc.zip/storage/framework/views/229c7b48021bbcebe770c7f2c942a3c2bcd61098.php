
<?php $__env->startSection('title', 'Create A New Booking'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h2 class="page-header-title"><?php echo e(__('Create A New Booking')); ?></h2>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0)"><?php echo e(__('Bookings')); ?></a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0)"><?php echo e(__('Add Booking')); ?></a></li>
                </ol>
            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <a href="<?php echo e(url('admin/booking')); ?>" class="btn btn-dark text-white"><?php echo e(__('Back To List')); ?></a>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('alertMessage.admin.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <form action="<?php echo e(url('admin/booking')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="card">
                    <div class="card-header d-flex align-items-center justify-content-between">
                        <div class="form-title">
                            <h4><?php echo e(__('Booking Form')); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label text-right" for="guest_id">
                                <?php echo e(__('Guest')); ?>

                                <small class="text-danger">*</small>
                            </label>
                            <div class="col-sm-10">
                                <select class="form-control js-basic-single" id="guest_id" name="guest_id">
                                    <option selected disabled>--Select Guest--</option>
                                    <?php $__empty_1 = true; $__currentLoopData = $guests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($guest->id); ?>"><?php echo e($guest->first_name.' '.$guest->last_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option>No Data</option>
                                    <?php endif; ?>
                                </select>
                                <?php $__errorArgs = ['guest_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label text-right" for="staff_id">
                                <?php echo e(__('Booked By')); ?>

                                <small class="text-danger">*</small>
                            </label>
                            <div class="col-sm-10">
                                <select class="form-control js-basic-single" id="staff_id" name="staff_id">
                                    <option selected disabled>--Select Staff--</option>
                                    <?php $__empty_1 = true; $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($staff->id); ?>"><?php echo e($staff->first_name.' '.$staff->last_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option>No Data</option>
                                    <?php endif; ?>
                                </select>
                                <?php $__errorArgs = ['staff_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label text-right">
                                <?php echo e(__('Checkin Date & Time')); ?>

                                <small class="text-danger">*</small>
                            </label>
                            <div class="col-sm-5">
                                <input type="date" class="form-control checkin-date" id="checkin_date" name="checkin_date">
                                <?php $__errorArgs = ['checkin_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-sm-5">
                                <input type="time" class="form-control" id="checkin_time" name="checkin_time">
                                <?php $__errorArgs = ['checkin_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label text-right">
                                <?php echo e(__('Checkout Date & Time')); ?>

                                <small class="text-danger">*</small>
                            </label>
                            <div class="col-sm-5">
                                <input type="date" class="form-control checkout-date" id="checkout_date" name="checkout_date">
                                <?php $__errorArgs = ['checkout_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-sm-5">
                                <input type="time" class="form-control" id="checkout_time" name="checkout_time">
                                <?php $__errorArgs = ['checkout_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label text-right">
                                <?php echo e(__('Total Guest')); ?>

                                <small class="text-danger">*</small>
                            </label>
                            <div class="col-sm-5">
                                <select class="form-control js-basic-single" id="total_adults" name="total_adults">
                                    <option selected disabled>--Select Total Adults--</option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                </select>
                                <?php $__errorArgs = ['total_adults'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-sm-5">
                                <select class="form-control js-basic-single" id="total_childs" name="total_childs">
                                    <option selected disabled>--Select Total Childs--</option>
                                    <option value="0">0</option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                </select>
                                <?php $__errorArgs = ['total_childs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label text-right" for="room_id">
                                <?php echo e(__('Available Rooms')); ?>

                                <small class="text-danger">*</small>
                            </label>
                            <div class="col-sm-10">
                                <select class="form-control js-basic-single room-list" id="room_id" name="room_id">
                                    
                                </select>
                                <?php $__errorArgs = ['room_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label text-right" for="booking_status">
                                <?php echo e(__('Booking Status')); ?>

                                <small class="text-danger">*</small>
                            </label>
                            <div class="col-sm-10">
                                <select class="form-control js-basic-single" id="booking_status" name="booking_status">
                                    <option value="0">Pending</option>
                                    <option value="1">Booked</option>
                                    <option value="2">Cancel</option>
                                </select>
                                <?php $__errorArgs = ['booking_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label text-right" for="booking_comment">
                                <?php echo e(__('Booking Comment')); ?>

                            </label>
                            <div class="col-sm-10">
                                <textarea class="form-control" id="booking_comment" name="booking_comment" rows="5" placeholder="Add booking comment..."></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="text-right">
                            <button type="submit" class="btn btn-primary text-uppercase text-right">
                                <?php echo e(__('Save')); ?>

                            </button>
                        </div>
                    </div>
                </div>

            </form>
        </div>
    </div>
</div>


<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $(".checkin-date").on('blur',function(){
            var _checkindate = $(this).val();
            // console.log(_checkindate);

            // Ajax
            $.ajax({
                url: "<?php echo e(url('admin/booking')); ?>/available-rooms/"+_checkindate,
                type: 'get',
                dataType: 'json',
                beforeSend: function(){
                    $(".room-list").html('<option>Loading...</option>');
                },
                success: function(res){
                    var _html = '';
                    $.each(res.data,function(index,row){
                        _html+='<option value="'+row.id+'">'+row.name+' - '+row.hotel_location+'</option>';
                    });
                    $(".room-list").html(_html);
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Works\Office\SYP\HBMS_HotelBookingManagementSystem\resources\views/admin/booking/create.blade.php ENDPATH**/ ?>