<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('app.name')); ?></title>

    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('admin/images/favicon.png')); ?>">

    <!-- Stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/vendor/pg-calendar/css/pignose.calendar.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/vendor/chartist/css/chartist.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/vendor/select2/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/vendor/summernote/summernote.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/vendor/dropify/dist/css/dropify.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/custom.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/style.css')); ?>">
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
    <div id="preloader">
        <?php echo $__env->make('layouts.inc.admin.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div id="main-wrapper">
        <div class="nav-header">
            <?php echo $__env->make('layouts.inc.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="header">
            <?php echo $__env->make('layouts.inc.admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>

        <div class="quixnav">
            <?php echo $__env->make('layouts.inc.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="content-body">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <div class="footer">
            <?php echo $__env->make('layouts.inc.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

    </div>


    
    <script src="<?php echo e(asset('admin/vendor/global/global.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/quixnav-init.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/custom.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/site.js')); ?>"></script>

    <script src="<?php echo e(asset('admin/vendor/chartist/js/chartist.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendor/moment/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendor/pg-calendar/js/pignose.calendar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendor/select2/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendor/summernote/js/summernote.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendor/dropify/dist/js/dropify.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/plugins-init/summernote-init.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/icons/feather-icons/feather.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/dashboard/dashboard-2.js')); ?>"></script>
    <?php echo \Livewire\Livewire::scripts(); ?>

    
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH E:\Works\Office\SYP\HBMS_HotelBookingManagementSystem\resources\views/layouts/admin.blade.php ENDPATH**/ ?>