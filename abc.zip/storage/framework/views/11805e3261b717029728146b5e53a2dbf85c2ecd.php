
<?php $__env->startSection('title', 'Room List'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h2 class="page-header-title"><?php echo e(__('Room List')); ?></h2>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0)"><?php echo e(__('Rooms')); ?></a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0)"><?php echo e(__('Room List')); ?></a></li>
                </ol>
            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <a href="<?php echo e(url('admin/room/create')); ?>" class="btn btn-success text-white mr-1"><?php echo e(__('Add Room')); ?></a>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <?php if(session('message')): ?>
                <?php echo $__env->make('alertMessage.admin.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.room.index', [])->html();
} elseif ($_instance->childHasBeenRendered('E82UNTq')) {
    $componentId = $_instance->getRenderedChildComponentId('E82UNTq');
    $componentTag = $_instance->getRenderedChildComponentTagName('E82UNTq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('E82UNTq');
} else {
    $response = \Livewire\Livewire::mount('admin.room.index', []);
    $html = $response->html();
    $_instance->logRenderedChild('E82UNTq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Works\Office\SYP\HBMS_HotelBookingManagementSystem\resources\views/admin/room/index.blade.php ENDPATH**/ ?>