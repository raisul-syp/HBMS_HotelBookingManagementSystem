<div class="sk-three-bounce">
    <div class="sk-child sk-bounce1"></div>
    <div class="sk-child sk-bounce2"></div>
    <div class="sk-child sk-bounce3"></div>
</div><?php /**PATH E:\Works\Office\SYP\HBMS_HotelBookingManagementSystem\resources\views/layouts/inc/admin/loader.blade.php ENDPATH**/ ?>