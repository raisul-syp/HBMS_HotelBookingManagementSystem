<nav class="navbar navbar-expand-lg navbar-light">
    <div class="container">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
            aria-expanded="false" aria-label="Toggle navigation">
            <span class="icon-bar"></span>
            <span class="icon-bar middle"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('frontend/images/logo.png')); ?>" alt="Zabeer Hotel International">
        </a>
        <button class="search-toggler d-block d-lg-none" type="button" data-bs-toggle="collapse"
            data-bs-target="#searchSupportedContent" aria-controls="searchSupportedContent"
            aria-expanded="false" aria-label="Toggle navigation">
            <i data-feather="search"></i>
        </button>
        <div id="navbarSupportedContent" class="collapse navbar-collapse justify-content-end">
            <ul class="navbar-nav">
                <?php $__currentLoopData = $menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(count($item->submenus) > 0): ?>
                <li class="nav-item">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false"><?php echo e($item->name); ?></a>
                      <ul class="dropdown-menu fade-down" aria-labelledby="navbarDropdown">
                        <?php $__currentLoopData = $item->submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenuItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a class="dropdown-item" href="<?php echo e($submenuItem->slug); ?>"><?php echo e($submenuItem->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                </li>
                <?php else: ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e($item->slug); ?>"><span><?php echo e($item->name); ?></span></a>
                </li>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if(Auth::user()): ?>
                <li class="nav-item">
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <a class="nav-link btn btn-primary btn-golden" href="<?php echo e(route('logout')); ?>" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Logout" onclick="event.preventDefault(); this.closest('form').submit();">
                            <i data-feather="power"></i>
                        </a>
                    </form>
                </li>
                <?php else: ?>
                <li class="nav-item">
                    <a class="nav-link btn btn-primary btn-golden" href="<?php echo e(route('login')); ?>" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Login">
                        <i data-feather="log-in"></i>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
        <div class="collapse search-collapse" id="searchSupportedContent">
            <div class="search-box">
                <form role="search">
                    <input class="form-control" type="search" placeholder="Search">
                    <button type="submit" class="btn btn-primary">
                        <i data-feather="search"></i>
                    </button>
                </form>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH E:\Works\Office\SYP\HBMS_HotelBookingManagementSystem\resources\views/layouts/inc/frontend/navbar.blade.php ENDPATH**/ ?>