<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('app.name')); ?></title>

    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('frontend/images/favicon.ico')); ?>">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito+Sans:ital,wght@0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap">
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap" rel="stylesheet">

    <!-- Stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/default.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/modules.css')); ?>">

    <!-- Vendor Stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/jquery-ui-1.13.2.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/vendors/animate_css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/vendors/bootstrap-5.0.2/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/vendors/select2/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/vendors/font-awesome-4.7.0/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/vendors/fontawesome-5.15.4/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/vendors/OwlCarousel2-2.3.4/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/vendors/OwlCarousel2-2.3.4/css/owl.theme.default.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/vendors/icon-font-1.0.0/icon-font.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/vendors/daterangepicker/daterangepicker.css')); ?>">

    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
    <div class="wrapper">
        <header id="header_section" class="header_section">
            <div class="header_section_inner">
                <div class="header_top">
                    <?php echo $__env->make('layouts.inc.frontend.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <div id="navbar_top" class="header_bottom">
                    <?php echo $__env->make('layouts.inc.frontend.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </header>

        <div class="main-body">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <footer id="footer_section" class="footer_section">
            <?php echo $__env->make('layouts.inc.frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </footer>

        <a href="#" class="back-to-top">
            <i data-feather="chevron-up"></i>
        </a>
    </div>


    <!-- Scripts -->
    <script src="<?php echo e(asset('frontend/js/jquery-3.6.1.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/jquery-ui-1.13.2.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/site.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/default.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/popper.js')); ?>"></script>

    <!-- Vendor Scripts -->
    <script src="<?php echo e(asset('frontend/vendors/bootstrap-5.0.2/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/vendors/isotope/isotope.pkgd.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/vendors/select2/js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/vendors/fontawesome-5.15.4/js/all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/vendors/OwlCarousel2-2.3.4/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/vendors/feathericons-4.29.0/feather.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/vendors/iconify-icon/iconify-icon.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/vendors/moment/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/vendors/daterangepicker/daterangepicker.min.js')); ?>"></script>
    <?php echo \Livewire\Livewire::scripts(); ?>

    
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>

<?php /**PATH E:\Works\Office\SYP\HBMS_HotelBookingManagementSystem\resources\views/layouts/guest.blade.php ENDPATH**/ ?>