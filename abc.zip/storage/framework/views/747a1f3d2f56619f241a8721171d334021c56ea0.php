
<?php $__env->startSection('title', 'Booking List'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h2 class="page-header-title"><?php echo e(__('Booking List')); ?></h2>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0)"><?php echo e(__('Bookings')); ?></a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0)"><?php echo e(__('Booking List')); ?></a></li>
                </ol>
            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <a href="<?php echo e(url('admin/booking/create')); ?>" class="btn btn-success text-white"><?php echo e(__('Add Booking')); ?></a>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <?php if(session('message')): ?>
                <?php echo $__env->make('alertMessage.admin.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.booking.index', [])->html();
} elseif ($_instance->childHasBeenRendered('bMo6Sbg')) {
    $componentId = $_instance->getRenderedChildComponentId('bMo6Sbg');
    $componentTag = $_instance->getRenderedChildComponentTagName('bMo6Sbg');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('bMo6Sbg');
} else {
    $response = \Livewire\Livewire::mount('admin.booking.index', []);
    $html = $response->html();
    $_instance->logRenderedChild('bMo6Sbg', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Works\Office\SYP\HBMS_HotelBookingManagementSystem\resources\views/admin/booking/index.blade.php ENDPATH**/ ?>