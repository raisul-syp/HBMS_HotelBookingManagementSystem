@extends('layouts.guest')
@section('title', 'Room View')

@section('content')

<section id="roomAvailability_section" class="roomAvailability_section">
    <div class="container">
        <div class="row">
            <div class="col-lg-9">
                {{-- {{ $roomDetails->name }} --}}
            </div>
        </div>
    </div>
</section>
@endsection
