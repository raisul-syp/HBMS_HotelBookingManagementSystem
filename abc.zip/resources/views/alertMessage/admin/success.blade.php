<div class="alert alert-success solid alert-right-icon alert-dismissible fade show">
    <span><i class="mdi mdi-check"></i></span>
    <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close"><span><i class="mdi mdi-close"></i></span>
    </button> {{ session('message') }}
</div>