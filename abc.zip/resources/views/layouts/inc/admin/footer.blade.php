<div class="copyright">
    <p>Copyright © Designed &amp; Developed by <a href="#" target="_blank">SYP Solutions Ltd.</a> 2022</p>
    <p>Distributed by <a href="#" target="_blank">SYP Solutions Ltd.</a></p>
</div>