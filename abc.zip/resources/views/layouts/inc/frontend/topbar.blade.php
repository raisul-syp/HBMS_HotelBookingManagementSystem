<div class="container">
    <div class="row">
        <div class="col-lg-6">
            <div class="header_top_left">
                <ul>
                    <li>
                        <i data-feather="map-pin"></i>
                        <span>1256 M M Ali Road, Jashore</span>
                    </li>
                    <li>
                        <i data-feather="mail"></i>
                        <span>sm@zabeerhotel.com</span>
                    </li>
                    <li>
                        <i data-feather="phone"></i>
                        <span>(+88) 01885-000-555</span>
                    </li>
                </ul>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="header_top_right">
                <ul>
                    <li class="facebook" data-bs-toggle="tooltip" data-bs-placement="bottom"
                        title="Facebook">
                        <a href="http://www.facebook.com/#">
                            <i data-feather="facebook"></i>
                        </a>
                    </li>
                    <li class="twitter" data-bs-toggle="tooltip" data-bs-placement="bottom"
                        title="Twitter">
                        <a href="http://twitter.com/#">
                            <i data-feather="twitter"></i>
                        </a>
                    </li>
                    <li class="instagram" data-bs-toggle="tooltip" data-bs-placement="bottom"
                        title="Instagram">
                        <a href="https://www.instagram.com/#">
                            <i data-feather="instagram"></i>
                        </a>
                    </li>
                    <li class="youtube" data-bs-toggle="tooltip" data-bs-placement="bottom"
                        title="YouTube">
                        <a href="http://www.youtube.com/user/#">
                            <i data-feather="youtube"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>